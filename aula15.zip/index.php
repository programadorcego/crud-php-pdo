<?php
require "config.php";
require "database.php";

$db = new Database();