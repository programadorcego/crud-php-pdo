<?php
class Database {
	private $pdo;
	
	public function __construct(){
		$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_DBNAME . ";charset=" . DB_CHARSET;
		
		try {
			$this->pdo = new PDO($dsn, DB_USER, DB_PASSWORD);
			$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
		} catch(PDOException $e){
			echo "Erro na conexão! " . $e->getMessage();
		}
	}
}