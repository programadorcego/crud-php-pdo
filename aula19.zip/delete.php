<?php
require "config.php";
require "database.php";

$db = new Database();

try {
	$db->Delete("usuarios", $_GET['id']);
	header("Location: index.php");
} catch(Exception $e){
	echo $e->getMessage();
}