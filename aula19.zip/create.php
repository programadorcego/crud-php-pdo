<?php
require "config.php";
require "database.php";

$dados = $_POST;
$dados['senha'] = md5($dados['senha']);

$db = new Database();
try {
	$db->create("usuarios", $dados);
	echo "Usuário cadastrado com sucesso!";
} catch(Exception $e){
	echo $e->getMessage();
}