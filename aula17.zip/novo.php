<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Cadastrar Usuário</title>
	</head>
	
	<body>
		<h1>Novo Usuário</h1>
		
		<form method="POST" action="create.php">
			<div>
				<label for="nome">Nome * </label>
				<input type="text" name="nome" id="nome" required placeholder="Informe seu nome">
			</div>
			
			<div>
				<label for="email">E-mail * </label>
				<input type="email" name="email" id="email" required placeholder="Informe seu e-mail">
			</div>
			
			<div>
				<label for="usuario">Nome de Usuário * </label>
				<input type="text" name="usuario" id="usuario" required placeholder="Informe seu nome de usuario">
			</div>
			
			<div>
				<label for="senha">Senha * </label>
				<input type="password" name="senha" id="senha" minlength="8" maxlength="16" required placeholder="Informe sua senha">
			</div>
			
			<div>
				<button>Salvar</button>
			</div>
		</form>
	</body>
</html>