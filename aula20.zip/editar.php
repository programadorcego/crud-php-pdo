<?php
session_start();

if(!isset($_SESSION['logado'])){
	header("Location: login.php");
}

require "config.php";
require "database.php";
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Atualizar Usuário</title>
	</head>
	
	<body>
		<h1>Editar Usuário</h1>
		
		<?php if(isset($_SESSION['mensagem'])) : ?>
		<div>
			<?php echo $_SESSION['mensagem']; ?>
		</div>
		<?php unset($_SESSION['mensagem']); endif; ?>
		
		<form method="POST" action="update.php?id=<?php echo $_GET['id']; ?>">
			<?php
				$id = $_GET['id'];
				$db = new Database();
				$usuario = $db->Read("usuarios", $id);
			?>
			<div>
				<label for="nome">Nome * </label>
				<input type="text" name="nome" id="nome" required placeholder="Informe seu nome" value="<?php echo $usuario->nome; ?>">
			</div>
			
			<div>
				<label for="email">E-mail * </label>
				<input type="email" name="email" id="email" required placeholder="Informe seu e-mail" value="<?php echo $usuario->email; ?>">
			</div>
			
			<div>
				<label for="usuario">Nome de Usuário * </label>
				<input type="text" name="usuario" id="usuario" required placeholder="Informe seu nome de usuario" value="<?php echo $usuario->usuario; ?>">
			</div>
			
			<div>
				<label for="senha">Senha * </label>
				<input type="password" name="senha" id="senha" minlength="8" maxlength="16" placeholder="Informe sua senha">
			</div>
			
			<div>
				<button>Salvar</button>
			</div>
		</form>
	</body>
</html>