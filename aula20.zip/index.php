<?php
session_start();

if(!isset($_SESSION['logado'])){
	header("Location: login.php");
}

require "config.php";
require "database.php";
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Usuários</title>
	</head>
	
	<body>
		<h1>Usuários</h1>
		
		<p><a href="logout.php">Sair</a></p>
		
		<table>
			<thead>
				<tr>
					<th>Nome</th>
					<th>E-mail</th>
					<th>Usuário</th>
					<th></th>
				</tr>
			</thead>
			
			<tbody>
				<?php
					$db = new Database();
					$usuarios = $db->Read("usuarios");
					if($usuarios) :
					foreach($usuarios as $usuario) :
				?>
				<tr>
					<td><a href="editar.php?id=<?php echo $usuario->id; ?>"><?php echo $usuario->nome; ?></a></td>
					<td><?php echo $usuario->email; ?></td>
					<td><?php echo $usuario->usuario; ?></td>
					<td><a href="delete.php?id=<?php echo $usuario->id; ?>">Excluir</a></td>
				</tr>
				<?php endforeach; ?>
				
				<?php else : ?>
				<tr>
					<td colspan="4">Nenhum usuário cadastrado</td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</body>
</html>