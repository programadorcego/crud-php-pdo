<?php
session_start();
require "config.php";
require "database.php";

$dados = $_POST;
$dados['atualizado_em'] = date('Y-md H:i:s');

if(!empty($dados['senha'])){
	$dados['senha'] = md5($dados['senha']);
} else {
	unset($dados['senha']);
}

$db = new Database();
try {
	$db->Update("usuarios", $dados, $_GET['id']);
	$_SESSION['mensagem'] = "Usuário atualizado com sucesso!";
} catch(Exception $e){
	$_SESSION['mensagem'] = $e->getMessage();
}

header("Location: editar.php?id=" . $_GET['id']);