<?php
session_start();

require "config.php";
require "database.php";

extract($_POST);
$senha = md5($senha);

$db = new Database();

try {
	$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND senha = '$senha' OR email = '$usuario' AND senha = '$senha'";
	$resultado = $db->query($sql);
	
	if($resultado->fetch()){
		$_SESSION['logado'] = true;
		header("Location: index.php");
	} else {
		header("Location: login.php");
	}
} catch(Exception $e){
	print $e->getMessage();
	die;
}