<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
	</head>
	
	<body>
		<h1>Login</h1>
		
		<form method="POST" action="logar.php">
			<div>
				<label for="usuario">Nome de Usuário ou E-mail* </label>
				<input type="text" name="usuario" id="usuario" required placeholder="Informe seu nome de usuário ou seu e-mail">
			</div>
			
			<div>
				<label for="senha">Senha * </label>
				<input type="password" name="senha" id="senha" minlength="8" maxlength="16" required placeholder="Informe sua senha">
			</div>
			
			<div>
				<button>Entrar</button>
			</div>
		</form>
	</body>
</html>