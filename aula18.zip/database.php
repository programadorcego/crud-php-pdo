<?php
class Database {
	private $pdo;
	
	public function __construct(){
		$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_DBNAME . ";charset=" . DB_CHARSET;
		
		try {
			$this->pdo = new PDO($dsn, DB_USER, DB_PASSWORD);
			$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
		} catch(PDOException $e){
			echo "Erro na conexão! " . $e->getMessage();
		}
	}
	
	public function create($tabela, $dados)
	{
		$colunas = implode(", ", array_keys($dados));
		$valores = implode(", ", array_fill(0, count($dados), "?"));
		
		try {
			$sql = "INSERT INTO $tabela ($colunas) VALUES ($valores)";
			$stmt = $this->pdo->prepare($sql);
			$stmt->execute(array_values($dados));
		} catch(PDOException $e){
			return throw new Exception("Erro! " . $e->getMessage());
		}
		
		$this->pdo = null;
		return true;
	}
	
	public function Read($tabela, int $id = 0) {
		try {
			$sql = "SELECT * FROM $tabela";
			
			if($id > 0){
				$sql .= " WHERE id = $id LIMIT 1";
			}
			
			$stmt = $this->pdo->prepare($sql);
			$stmt->execute();
			
			if($id > 0){
				$resultados = $stmt->fetch();
				$this->pdo = null;
				return $resultados;
			}
			
			$resultados = $stmt->fetchAll();
			$this->pdo = null;
			return $resultados;
		} catch(PDOException $e){
			return new Exception($e->getMessage());
		}
	}
	
	public function Update($tabela, $dados, $id){
		$campos = [];
		
		foreach($dados as $k => $v){
			$campos[] = "{$k}=?";
		}
		
		$campos = implode(", ", $campos);
		$dados['id'] = $id;
		
		try {
			$sql = "UPDATE $tabela SET $campos WHERE id=?";
			$stmt = $this->pdo->prepare($sql);
			$stmt->execute(array_values($dados));
			$this->pdo = null;
		} catch(PDOException $e){
				return throw new Exception("Erro! " . $e->getMessage());
		}
	}
}